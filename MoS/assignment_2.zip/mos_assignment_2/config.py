import os

ASSIGNMENT_PATH = '/Users/marcel.garcia/Desktop/mos_assignment_2'
FILES_PATH = os.path.join(ASSIGNMENT_PATH, 'files/')
IMGS_PATH = os.path.join(ASSIGNMENT_PATH, 'static/')
COLLECTION_PATH = os.path.join(FILES_PATH, 'collection/')
YOLO_PATH = os.path.join(ASSIGNMENT_PATH, 'lib/yolov3-coco/')