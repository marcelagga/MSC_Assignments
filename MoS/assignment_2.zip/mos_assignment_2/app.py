from flask import Flask, redirect, url_for, request, render_template
from lib.ir import TextProcessor, InformationRetrieval
from config import COLLECTION_PATH, FILES_PATH
import csv

app = Flask(__name__)


@app.route('/query/<query_user>')
def index(query_user):
    with open(FILES_PATH + 'image_conversion.csv', mode='r') as inp:
        reader = csv.reader(inp)
        image_conversion = {rows[1]: rows[0] for rows in reader}
    tp = TextProcessor(COLLECTION_PATH)
    docs_processed = tp.get_docs_processed()

    ir = InformationRetrieval(docs_processed)
    ir.calculate_inverted_index()
    ir.calculate_length_docs()

    query = tp.process_text(query_user)

    images_id = [image_conversion[doc[0]] for doc in ir.get_relevant_documents(query, 'BM25')[:10] if
                 image_conversion[doc[0]].split('.')[-1] != 'svg']
    return render_template('successful.html', title='Welcome', members=images_id)


@app.route('/')
@app.route('/query', methods=['POST', 'GET'])
def get_query():
    if request.method == 'POST':
        user = request.form['nm']
        return redirect(url_for('index', query_user=user))
    else:
        user = request.args.get('nm')
        return redirect(url_for('index', query_user=user))


if __name__ == '__main__':
    app.run(debug=True)
