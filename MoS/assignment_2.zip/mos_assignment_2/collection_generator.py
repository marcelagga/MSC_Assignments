from lib.ir import ImageHTMLContentRetrieval
from config import COLLECTION_PATH,IMGS_PATH,FILES_PATH,YOLO_PATH

if __name__ == '__main__':
    CR = ImageHTMLContentRetrieval(COLLECTION_PATH, IMGS_PATH, FILES_PATH, YOLO_PATH)
    CR.get_classes()
    print("Generating Metadata Collection...")
    CR.generate_metadata_collection()
    print("Adding yolo information...")
    CR.yolo_add_information_to_collection()
    print("Saving matrix...")
    CR.document_matrix[['image_name', 'document_id']].to_csv(FILES_PATH+'image_conversion.csv', index=False)