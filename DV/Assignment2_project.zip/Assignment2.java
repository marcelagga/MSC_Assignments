/*

Assignment 2
Name: Marcel Aguilar Garcia
Student ID: 20235620

 */

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Assignment2 {

    public static void main(String[] args) {

        /*
        Main:

        In Main I have intialised an array with times. I have decided to use epoch times to encode the time
        as it is a suitable encoding to represent time as an integer. The epoch times that I have chosen
        represent different times of the same date, 28 February 2021.

        I have created three different weather stations for three different cities (Barcelona, Valencia, and Madrid).
        The temperatures per each city are represented as an array of doubles (e.g., temperaturesBarcelona).
        The index of the temperature is aligned with the time, temperaturesBarcelona[i] happened at epochtime[i].
        In this way, I can create different measurements Measurement(epochtime[i],temperaturesBarcelona[i]) per
        each of the stations.

        Finally, I initialise three different weather stations and add their respective measurements as an array
        of measurements.

        For this exercise, I have called maxTemperature for the weather station from Barcelona between two
        specific times and calculated countTemperatures between two different ranges for all the stations.

        */

        long[] epochtimes = {1614470400,1614474000,1614477600,1614481200,1614484800,1614488400,1614492000,
                1614495600,1614499200,1614502800,1614506400,1614510000,1614513600,1614517200,1614520800,
                1614524400, 1614528000,1614531600,1614535200,1614538800,1614542400,1614546000,1614549600,
                1614553200};

        double[] temperaturesBarcelona = {18.8,19.3,17.4,20.5,14.2,21.1,22.0,17.3,19.10,18.8,20.1,20.2,18.7,17.8,19.4,
                24.5,17.2,26.1,25.0,17.3,19.10,18.8,20.1,20.2};

        double[] temperaturesMadrid = {20.5,19.1,17.4,21.5,15.2,19.1,33,27.3,19.10,18.8,30.1,30.5, 12.7,12.8,39.4,26.5,
                17.4,24.1,25.4,11.3,15.10,16.8,19.1,1};

        double[] temperaturesValencia = {3.5,8.1,7.4,1.5,5.6,9.1,3,2.3,9.10,8.8,3.1,3.6,1.7,1.8,3.7,2.5,7.4,2.7,5.4,
                1.5,5.10,1.8,9.1,1.5};

        ArrayList<Measurements> measurementsBarcelona = new ArrayList<>();
        ArrayList<Measurements> measurementsMadrid = new ArrayList<>();
        ArrayList<Measurements> measurementsValencia = new ArrayList<>();

        for(int i=0;i<epochtimes.length;i++){
            measurementsBarcelona.add(new Measurements(epochtimes[i],temperaturesBarcelona[i]));
            measurementsMadrid.add(new Measurements(epochtimes[i],temperaturesMadrid[i]));
            measurementsValencia.add(new Measurements(epochtimes[i],temperaturesValencia[i]));
        }

        //Initializing weather stations with the respective measurements:
        WeatherStation WSBarcelona = new WeatherStation("Barcelona",measurementsBarcelona);
        WeatherStation WSMadrid = new WeatherStation("Madrid",measurementsMadrid);
        WeatherStation WSValencia = new WeatherStation("Valencia",measurementsValencia);

        //Using maxTemperature method to print the Maximum Temperature in Barcelona between 1614470400 and 1614488400
        System.out.println("The maximum temperature in " + WSBarcelona.getCity() +
                " between 1614470400 and 1614488400 was " + WSBarcelona.maxTemperature(1614470400,1614488400) );

        /*Using countTemperatures to count the temperatures within the ranges. In this specific example
        the ranges are for t1: [20.5-3.1,20.5+3.1] and for t2:[10.3-3.1,10.3+3.1]*/

        double t1 = 20.5;
        double t2 = 10.1;
        double r = 3.1;

        for(WeatherStation.temperatureCountings Result:WeatherStation.countTemperatures(t1,t2,r)){
            System.out.println("There are " + Result.counting + " temperatures recorded in all the stations that " +
                    "are between " + (Result.temperatureRange-r) + " and " +
                    (Result.temperatureRange+r));
        }

    }
}

/*
* Class WeatherStation created following the requirements of the exercise.
* This WeatherStation has three different attributes: city, measurements, and stations.
* Stations is a static array that stores the different instances of WeatherStations.
* In order to achieve this, I am adding each instance in the static attribute stations
* in the constructor.
* */

class WeatherStation {
    private String city;
    private ArrayList<Measurements> measurements;
    static ArrayList<WeatherStation> stations = new ArrayList<>();

    WeatherStation(String city, ArrayList<Measurements> measurements) {
        this.city = city;
        this.measurements = measurements;
        stations.add(this);
    }

    public ArrayList<Measurements> getMeasurements() {
        return this.measurements;
    }

    public String getCity(){
        return this.city;
    }

    /*
    This method returns the maximum temperature between startTime and endTime using streams:
    1. First filters all measurements between these two times, then
    2. Maps each measurement to their temperature: (time,temperature) -> temperature, then
    3. Uses 'max()' to return the maximum value
    */
    public double maxTemperature(int startTime, int endTime) {
        return measurements
                .stream()
                .filter(measurement->measurement.getTime() >= startTime & measurement.getTime() <= endTime)
                .mapToDouble(measurement->measurement.getTemperature())
                .max().getAsDouble();
    }


    /*
    This static class will be used to construct datastructures such as (t1,c1) and (t2,c1)
    where t1 and t2 are the temperatures passed as parameters to countTemperatures and
    c1 and c2 are the counts of each temperature in each of the ranges.

    The final result for Question2 can be represented as an array of temperatureCountings
    */

    static class temperatureCountings{
        double temperatureRange;
        int counting;
        temperatureCountings(double temperatureRange, int counting){
            this.temperatureRange = temperatureRange;
            this.counting = counting;
        }
    }

    /* This static method returns an array of temperature counting which is the final result from Question 2.
       I have implemented this method in three different phases: Map phase, Shuffle phase and Reduce phase
    */

    static List<temperatureCountings> countTemperatures(double t1,double t2,double r){

    /*
    This static class is used to define a datastructure such as (t1,1) and (t2,1)
    for the phase of mapping.
    */

         class Pair{
            double temperatureRange;
            int temperature;

            Pair(double temperatureRange,int temperature){
                this.temperatureRange = temperatureRange;
                this.temperature = temperature;
            }

            public double getTemperatureRange(){
                return this.temperatureRange;
            }
        }

        //MAP

        /*

        MapPhase maps each temperature t to (t1,1) and/or (t2,1)
        in case that t is in the range [t1-r,t1+r] and/or [t2-r,t2+r] respectively.

        MapPhase is collected to a list as, during Shuffle, I will apply the filter method twice
        to the same object. I couldn't do that if I was using streams.

        */

        List<Pair> MapPhase = stations.parallelStream().
                flatMap(station -> station.getMeasurements().parallelStream()).
                map(c->c.getTemperature()).
                flatMap(s -> {
                    ArrayList<Pair> ArrayPairs = new ArrayList<>();
                    if (s >= t1-r & s <=t1+r) {
                        ArrayPairs.add(new Pair(t1,1));
                    }
                    if (s >= t2-r & s <=t2+r) {
                        ArrayPairs.add(new Pair(t2,1));
                    }
                    return ArrayPairs.stream();
                }).collect(Collectors.toList());

        /*

        I thought about two solutions for SHUFFLE and REDUCE. In the first solution I am aiming to directly
         use reduce to return an array - which is the final solution.

         However, by doing that I had to convert each of the streams from the ShufflePhase to collections which
         is not very efficient. Additionally, I had problems dealing with the case of temperature count = 0 and
         trying to retrieve t1/t2 as I did not have any elements on the array. This solution works as expected when
         the count > 0. See below:

        SHUFFLE
        ShufflePhase splits the array from the MapPhase into two separated streams
        one per each temperature.


        Stream<List<Pair>> ShufflePhase = Stream.of(
                MapPhase.parallelStream().filter(x->x.temperatureRange == t1).collect(Collectors.toList()),
                MapPhase.parallelStream().filter(x->x.temperatureRange == t2).collect(Collectors.toList()));

        REDUCE

        List<TemperatureCountings> ReducePhase  = ShufflePhase.parallel()
                .map(t->{
                    return new TemperatureCountings(t.get(0).temperatureRange, (int) t.stream().mapToInt(s->s.temperature).sum());
                })
                .collect(Collectors.toList());*/


        /*
        I have finally opt for the second solution. In this solution, ShufflePhase
          is a stream fo streams. During the ReducePhase I can count elements of each stream
          and return them into an array. This is not the datastructure that we are required for the exercise
          and I have to manually add this elements into an array which is then returned.
          See below:

         */

        //SHUFFLE

        //ShufflePhase splits the array from the MapPhase into two separated streams
        //one per each temperature.
        Stream<Stream> ShufflePhase = Stream.of(
                MapPhase.parallelStream().filter(x->x.temperatureRange == t1),
                MapPhase.parallelStream().filter(x->x.temperatureRange == t2));


        //REDUCE

        //Finally, ReducePhase counts the elements in each of the ranges
        //It uses parallel to perform the operation in different threads
        List<Long> ReducePhase = ShufflePhase.parallel().
                map(s-> s.count())
                .collect(Collectors.toList());

        //The counts given by the ReducePhase can be added in an array
        //with the required datastructures for the result:
        //[(t1,count1),(t2,count2)]

        ArrayList<temperatureCountings> ResultTemperatures = new ArrayList<>();
        ResultTemperatures.add(new temperatureCountings(t1,ReducePhase.get(0).intValue()));
        ResultTemperatures.add(new temperatureCountings(t2,ReducePhase.get(1).intValue()));

        return ResultTemperatures;
    }
}
//Measurement class defined with attributes for time (integer) and temperature (double)
class Measurements{
    private long time;
    private double temperature;

    Measurements(long time, double temperature){
        this.time = time;
        this.temperature = temperature;
    }
    public long getTime(){
        return time;
    }
    public double getTemperature(){
        return temperature;
    }
}