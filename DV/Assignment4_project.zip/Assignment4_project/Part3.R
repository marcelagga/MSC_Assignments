#Loading all required R libraries

library(readxl)
library(tidyverse)
library(ggplot2)
library(dplyr)
library(grid)
library(gtable)
library(extrafont)
library(ggridges)
library(scales)
library(lubridate)

#I start by loading the data

data <- read.csv('OECD_PISA.csv',fileEncoding="UTF-8-BOM")  %>%
  
  #There are just four columns that are required to create this plot
  #which I have renamed to a more appropiate name: Country, Gender, Year and AverageScore
  
  select('LOCATION','SUBJECT','TIME','Value') %>%
  
  dplyr::rename(Country = 'LOCATION',Gender = 'SUBJECT',Year = 'TIME',AverageScore = 'Value') %>%
  
  #This plot is using the data from 2018. In this step I filter all rows from 2018.
  #In a similar way, I am just interested with the average of Girls and Boys and therefore,
  #I am filtering out all data related to totals
  
  filter(Gender=='TOT') %>%
  #The country names are using a short name and I have updated them with their real name.
  
  mutate(CountryLong=recode(Country,"IDN" = "Indonesia", "BRA" = "Brazil","COL" ="Colombia",
                            "MEX" ="Mexico","CRI" ="Costa Rica","GRC" ="Greece","SVK" ="Slovak Republic",
                            "CHL" ="Chile","ISR" ="Israel","TUR" ="Turkey","ISL" ="Iceland",
                            "LUX" ="Luxembourg","LTU" ="Lithuania","LVA" ="Latvia","HUN" ="Hungary",
                            "ITA" ="Italy","RUS" ="Russia","CHE" ="Switzerland","NLD" ="Netherlands",
                            "AUT" ="Austria","OAVG" ="OECD-Average","CZE" ="Czech Republic","SVN" ="Slovenia",
                            "NOR" ="Norway","FRA" ="France","PRT" ="Portugal","BEL" ="Belgium","DEU" ="Denmark",
                            "DNK" ="Germany","AUS" ="Australia","SWE" ="Sweden","NZL" ="New Zealand","JPN" ="Japan",
                            "GBR" ="United Kingdom","USA" ="United States","FIN" ="Finland","POL" ="Poland",
                            "KOR" ="Korea","CAN" ="Canada","IRL" ="Ireland","EST" ="Estonia"))%>%
  
  #Finally, I update the categories Boy and Girl to be the plural (as seen in the original plot)
  
  mutate(Gender = recode(Gender,"BOY" = "Boys","GIRL" = "Girls")) %>%
  mutate(Year=paste0(Year, "-01-01"))%>%
  mutate(Year= as.Date(Year, format="%Y-%m-%d"))

#I calculate the averages per year from all the countries and add this rows into the tibble
#this will be used to compare the selection of countries to the whole averages

Average <- group_by(data, Year) %>% summarize(AverageScore = mean(AverageScore))
Average$Gender <- "TOT"
Average$Country <- "AVG"
Average$CountryLong <- "Average"
data<- bind_rows(data,Average %>% relocate(Country,Gender,Year,AverageScore))

#The data is ordered by Gender, Average Score and finally, Country (alphabetically). I used
#factors to make sure that the this order will be used by ggplot.

GermanicCountries <- c("Sweden","Norway","Germany","Iceland","Netherlands","Belgium","Average")
data <- data %>% filter(CountryLong %in% GermanicCountries)

#I select the AverageScores of the last year to be able to position y labels in the right place

data_final <- filter(data, Year == ymd("2018-01-01"))
data_final<- data_final%>%
  mutate(pos=AverageScore)%>%
  mutate(pos = case_when(
    Country=="SWE" ~ pos+0.2,
    Country=="DNK" ~ pos+0.3,
    Country=="BEL" ~ pos+0.2,
    TRUE ~ pos)
  )

#I finally use ggplot to initialise the plot, variable x is set to be the year and variable y
#is set to be the AverageScore. The colour and alpha will will be different
#depending on the country. I will be setting a lower alpha to Countries in relation
#to the average to facilitate the distinction

g <- ggplot(data, aes(Year, AverageScore, color = Country))

#As I will be comparing average of different years I decide to use a line
#the thickness of the line was too small so I decided to increase it a bit

g <- g +   geom_line(size=1.3,alpha = 0.6)


#I have modified the margins of x and y so there will be a bit of space left
#between the plot and edges of the background. Additionally,
#as the data from the countries comes every 3 years I am changing the breaks of
#Axis x to be aligned with these years. I have changed the gridlines and labels
#for axis y to look similar to the original plot. I am labeling the Countries
#at the end of each line

g<- g+ scale_y_continuous(limits = c(468, 520),
                          breaks = seq(468, 518, len = 6),
                          labels=seq(470, 520, len = 6),
                          expand = c(0.05, 0),
                          sec.axis = dup_axis(
                            breaks = data_final$pos,
                            labels = data_final$Country,
                            name = NULL))+
  scale_x_date(name = "Year",
               breaks = seq(as.Date("2000-01-01"),
                            as.Date("2018-01-01"), by="3 years"),
               labels=date_format("%Y"),
               expand = expansion(mult = c(0.04, 0.01)))

#I set a more appropiate qualitative palette of colours
g<- g+  scale_color_manual(values =  c("black","#cb252b", "#b031bf", "#3735d0", "#3a9c4a","#9aa928","#af5423"),
                           name = NULL)

#I was not able to use annotate to set a line on the top as in the previous plot
#but I found this workaround to work good
g<- g+ geom_segment(y = 522.5,yend = 522.5,x = -Inf,xend = Inf,colour = "steelblue3",size = 0.8)

#Finally, I use the same featurse as in previous plot for the theme
#I have decided to add a subtitle in this case to put emphasis to
#the selected countries
g<- g+theme(legend.position = "none",
            panel.background = element_rect(fill = "#dee8ef"),
            plot.margin = margin(14, 7, 3, 1.5),
            panel.grid.major.x = element_blank(),
            panel.grid.minor.x = element_blank(),
            panel.grid.minor.y = element_blank(),
            axis.title.x = element_blank(),
            axis.title.y = element_blank(),
            axis.line.y.right = element_blank(),
            axis.ticks.y = element_blank(),
            axis.text.y.left = element_text(hjust = 0,vjust=-1),
            plot.title = element_text(face="bold",family = "serif",size=15),
            axis.text.y.right = element_text(margin = margin(0, 0, 0, 0) ,size = 8),
)+ labs(title = "Reading Performance per year (PISA)",            
        subtitle = "Countries with Germanic languages")

#In order to expand the background over axis y I had to use the trick below I was able to find this
#information in:
#https://stackoverflow.com/questions/46626326/ggplot2-y-axis-labels-left-justified-inside-plot-area
#The main idea is focus on updating the ggplot to a ggplotGrob and changing the label grob related
#to y axis
gp <- ggplotGrob(g)
y.label.grob <- gp$grobs[[which(gp$layout$name == "axis-l")]]$children$axis    
gp$grobs[[which(gp$layout$name == "axis-l")]] <- zeroGrob()
gp$widths[gp$layout$l[which(gp$layout$name == "axis-l")]] <- unit(0, "cm")
new.y.label.grob <- gtable(heights = unit(1, "npc"))
new.y.label.grob <- gtable_add_cols(new.y.label.grob,
                                    widths = y.label.grob[["widths"]][2])
new.y.label.grob <- gtable_add_grob(new.y.label.grob,
                                    y.label.grob[["grobs"]][[2]],
                                    t = 1, l = 1)
new.y.label.grob <- gtable_add_cols(new.y.label.grob,
                                    widths = y.label.grob[["widths"]][1])
new.y.label.grob <- gtable_add_grob(new.y.label.grob,
                                    y.label.grob[["grobs"]][[1]],
                                    t = 1, l = 2)
new.y.label.grob <- gtable_add_cols(new.y.label.grob,
                                    widths = unit(1, "null"))
gp <- gtable_add_grob(gp,
                      new.y.label.grob,
                      t = gp$layout$t[which(gp$layout$name == "panel")],
                      l = gp$layout$l[which(gp$layout$name == "panel")])

grid.draw(gp)