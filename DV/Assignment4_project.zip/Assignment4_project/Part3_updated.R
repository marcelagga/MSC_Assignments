#Loading all required R libraries

library(readxl)
library(tidyverse)
library(ggplot2)
library(dplyr)
library(grid)
library(gtable)
library(extrafont)
library(ggridges)
library(scales)
library(lubridate)

#I start by loading the data

data <- read.csv('OECD_PISA.csv',fileEncoding="UTF-8-BOM")  %>%
  
  #There are just four columns that are required to create this plot
  #which I have renamed to a more appropiate name: Country, Gender, Year and AverageScore
  
  select('LOCATION','SUBJECT','TIME','Value') %>%
  
  dplyr::rename(Country = 'LOCATION',Gender = 'SUBJECT',Year = 'TIME',AverageScore = 'Value') %>%
  
  #This plot is using the data from 2018. In this step I filter all rows from 2018.
  #In a similar way, I am just interested with the average of Girls and Boys and therefore,
  #I am filtering out all data related to totals
  
  filter(Gender!='TOT') %>%
  #The country names are using a short name and I have updated them with their real name.
  
  mutate(CountryLong=recode(Country,"IDN" = "Indonesia", "BRA" = "Brazil","COL" ="Colombia",
                            "MEX" ="Mexico","CRI" ="Costa Rica","GRC" ="Greece","SVK" ="Slovak Republic",
                            "CHL" ="Chile","ISR" ="Israel","TUR" ="Turkey","ISL" ="Iceland",
                            "LUX" ="Luxembourg","LTU" ="Lithuania","LVA" ="Latvia","HUN" ="Hungary",
                            "ITA" ="Italy","RUS" ="Russia","CHE" ="Switzerland","NLD" ="Netherlands",
                            "AUT" ="Austria","OAVG" ="OECD-Average","CZE" ="Czech Republic","SVN" ="Slovenia",
                            "NOR" ="Norway","FRA" ="France","PRT" ="Portugal","BEL" ="Belgium","DEU" ="Denmark",
                            "DNK" ="Germany","AUS" ="Australia","SWE" ="Sweden","NZL" ="New Zealand","JPN" ="Japan",
                            "GBR" ="United Kingdom","USA" ="United States","FIN" ="Finland","POL" ="Poland",
                            "KOR" ="Korea","CAN" ="Canada","IRL" ="Ireland","EST" ="Estonia"))%>%
  
  #Finally, I update the categories Boy and Girl to be the plural (as seen in the original plot)
  
  mutate(Gender = recode(Gender,"BOY" = "Boys","GIRL" = "Girls")) %>%
  mutate(Year=paste0(Year, "-01-01"))%>%
  mutate(Year= as.Date(Year, format="%Y-%m-%d"))

#The subset of countries (Nordic Countries) is filtered from the whole data set
NordicCountries <- c("Denmark","Finland","Iceland","Norway","Sweden")
data <- data %>% filter(CountryLong %in% NordicCountries)

#The plot is initialize with axis x representing the years and axis y the average score 
g <- ggplot(data, aes(x=Year, y=AverageScore))

#In order to follow a simlar style than the plot from plot 2, a blue top line is added as
#an annotation
g<-g+geom_segment(y = 577,yend = 577,x = -Inf,xend = Inf,colour = "steelblue3",size = 0.8)


#By using facets, I split the plot per country using to visualise the score per gender
g<-g+ facet_grid(cols = vars(CountryLong))+
  geom_line(size = 1, aes(colour=Gender)) 

#I override the colours defaulted by ggplot to a more color blind friendly option
g <- g+scale_colour_manual(values=c("#0072B2","#009E73"))

#Axis x is changed to show labels for every 3 years (being aligned with the data)
#There was no need to change axis y and I have left the default values (I am happy 
#with the breaks happening every 25 units)
g<-g+ scale_x_date(breaks = seq(as.Date("2000-01-01"),
                            as.Date("2018-01-01"), by="3 years"),
               labels=date_format("%Y"))

g <- g+ggtitle("Reading performance (PISA): Nordic Countries")
#Finally, a similar team than in the plot from part 2 is used
g<-g+
  theme(
    panel.background = element_rect(fill = "#dee8ef"),
    axis.line.x = element_blank(),
    axis.ticks.x = element_blank(),
    axis.title.x = element_blank(),
    axis.text.x = element_text(angle = 45, vjust = 1, hjust = 1,size = 7.5,family = "Times New Roman"),
    axis.line.y = element_blank(),
    axis.ticks.y = element_blank(),
    axis.title.y = element_blank(),
    panel.grid.major.x = element_blank(),
    panel.grid.minor.x = element_blank(),
    panel.grid.minor.y = element_blank(),
    legend.justification="left",
    legend.position = "bottom",
    legend.direction="horizontal",
    legend.background = element_blank(),
    legend.title = element_blank(),
    legend.key = element_rect(fill = "white"),
    plot.title = element_text(face="bold",family = "serif",size=15),
    strip.background = element_blank(),
    strip.text.x = element_text(size=9, face="bold"),
    axis.text.y = element_text(hjust = 0,vjust=1))


ggsave('part3_v2.png')
g