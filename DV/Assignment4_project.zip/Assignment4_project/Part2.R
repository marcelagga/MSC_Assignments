#Loading all required R libraries

library(readxl)
library(tidyverse)
library(ggplot2)
library(dplyr)
library(grid)
library(gtable)
library(extrafont)

loadfonts(device="win")

#I start by loading the data

data <- read.csv('OECD_PISA.csv',fileEncoding="UTF-8-BOM")  %>%
  
  #There are just four columns that are required to create this plot
  #which I have renamed to a more appropiate name: Country, Gender, Year and AverageScore
  
  select('LOCATION','SUBJECT','TIME','Value') %>%
  
  dplyr::rename(Country = 'LOCATION',Gender = 'SUBJECT',Year = 'TIME',AverageScore = 'Value') %>%
  
  #This plot is using the data from 2018. In this step I filter all rows from 2018.
  #In a similar way, I am just interested with the average of Girls and Boys and therefore,
  #I am filtering out all data related to totals
  
  filter(Year==2018 & Gender!='TOT') %>%
  
  #The country names are using a short name and I have updated them with their real name.
  
  mutate(Country=recode(Country,"IDN" = "Indonesia", "BRA" = "Brazil","COL" ="Colombia",
                        "MEX" ="Mexico","CRI" ="Costa Rica","GRC" ="Greece","SVK" ="Slovak Republic",
                        "CHL" ="Chile","ISR" ="Israel","TUR" ="Turkey","ISL" ="Iceland",
                        "LUX" ="Luxembourg","LTU" ="Lithuania","LVA" ="Latvia","HUN" ="Hungary",
                        "ITA" ="Italy","RUS" ="Russia","CHE" ="Switzerland","NLD" ="Netherlands",
                        "AUT" ="Austria","OAVG" ="OECD-Average","CZE" ="Czech Republic","SVN" ="Slovenia",
                        "NOR" ="Norway","FRA" ="France","PRT" ="Portugal","BEL" ="Belgium","DEU" ="Denmark",
                        "DNK" ="Germany","AUS" ="Australia","SWE" ="Sweden","NZL" ="New Zealand","JPN" ="Japan",
                        "GBR" ="United Kingdom","USA" ="United States","FIN" ="Finland","POL" ="Poland",
                        "KOR" ="Korea","CAN" ="Canada","IRL" ="Ireland","EST" ="Estonia"))%>%
  
  #Finally, I update the categories Boy and Girl to be the plural (as seen in the original plot)
  
  mutate(Gender = recode(Gender,"BOY" = "Boys","GIRL" = "Girls"))

#The data is ordered by Gender, Average Score and finally, Country (alphabetically). I used
#factors to make sure that the this order will be used by ggplot.

data <- data %>% arrange(Gender,desc(AverageScore),desc(Country))
data$Country <- factor(data$Country,levels = rev(unique(data$Country)))
#I am defining the texts that will be used next to the title in here

Text1 = textGrob("Boys/Girls, Mean, score, 2018", gp = gpar(col = "black", fontsize = 7,fontface = "bold"))
Text2 = textGrob("Source:PISA:Programme for International Student Assessment", gp = gpar(col = "black", fontsize = 7,fontface = "bold"))

#I finally use ggplot to initialise the plot, variable x is set to be the Country and variable y
#is set to be the AverageScore. The shape, colour and fill will will be different
#depending on the Gender variable (Boys and Girls)

g <- ggplot(data, aes(x=Country, y=AverageScore,shape=Gender,colour=Gender,fill=Gender))

#I start by defining the vertical gridlines. The reason for that is that later on
#I will want the filling of one of the shapes to override the line so, the line
#will not be seen inside the shape. I have used different paramaters to make sure
#they look as closed as possible to the original plot.

g <- g +  geom_segment(data = data %>% filter(Gender == "Girls"),aes(xend =  Country), yend = 340, colour="grey", size=0.3)+
  geom_segment(data = data %>% filter(Gender == "Boys"), aes(xend = Country), yend = 340, colour="white", size=0.3)

#Finally, I add all points into the plot and define the shapes
#colours and fillings per category (boys/girls).

g <- g + geom_point(size=2.5, stroke = 1)+
  scale_shape_manual(values = c(21, 23))+
  scale_colour_manual(values = c( "#608098","#608098"))+
  scale_fill_manual(values = c("#608098","#dee8ef"))

#Dots that are highlighted (average and Ireland) are defined in here with the
#required colours (black and red respectively).

g <- g + geom_point(data = data %>% filter(Country == "Ireland" & Gender == "Boys"),  
                    aes(x=Country, y=AverageScore,shape=Gender,colour=Gender,fill=Gender),
                    colour="red", size=2.5,shape=21,stroke=1,fill="red")+
  geom_point(data = data %>% filter(Country == "Ireland" & Gender == "Girls"),  
             aes(x=Country, y=AverageScore,shape=Gender,colour=Gender,fill=Gender),
             colour="red", size=2.5,shape=23,stroke=1,fill="red")+
  geom_point(data = data %>% filter(Country == "OECD-Average" & Gender == "Boys"),  
             aes(x=Country, y=AverageScore,shape=Gender,colour=Gender,fill=Gender),
             colour="black", size=2.5,shape=21,stroke=1,fill="black")+
  geom_point(data = data %>% filter(Country == "OECD-Average" & Gender == "Girls"),  
             aes(x=Country, y=AverageScore,shape=Gender,colour=Gender,fill=Gender),
             colour="black", size=2.5,shape=23,stroke=1,fill="black")

#The scale/limits of axis x and y are a bit different from the expected one.
#I have done some changes using expand and limits. Additionally,
#The labels of axis y are overridened with different numbers (as seen in original plot).

g <-   g + scale_x_discrete(expand = c(0.05,0))+
  scale_y_continuous(limits = c(350,570),breaks = seq(350, 570, len = 12),
                     labels=seq(340, 560, len = 12))

#Title and annotations (title subtitles and line on the top) are added in here.
#I need to change the limits of the plot and use clip=off in order to be able
#to go out of these limits.

g <- g + coord_cartesian(ylim = c(342,565),clip = "off")+
  annotation_custom(grob = Text1,  xmin = "Luxembourg", xmax = "Russia", ymin = 583, ymax = 590)+
  annotation_custom(grob = Text2,  xmin = "Australia", xmax = "Ireland", ymin = 583, ymax = 590)+
  annotate(geom = 'segment',y = Inf,yend = Inf,x = -Inf,xend = Inf,colour = "steelblue3",size = 0.8)+
  ggtitle("Reading performance (PISA)")

#Finally, all information related to axis, legend, and other remaining details are modified in the theme

g<- g + theme(panel.background = element_rect(fill = "#dee8ef"),
              axis.line.x = element_blank(),
              axis.ticks.x = element_blank(),
              axis.title.x = element_blank(),
              axis.text.x =
                element_text(angle = 45, vjust = 1, hjust = 1,size = 7.5,family = "Times New Roman",
                             face   = ifelse(levels(data$Country) == "OECD-Average",'bold','plain'),
                             colour = ifelse(levels(data$Country) == "Ireland","red","black")),
              axis.line.y = element_blank(),
              axis.ticks.y = element_blank(),
              axis.title.y = element_blank(),
              panel.grid.major.x = element_blank(),
              panel.grid.minor.x = element_blank(),
              panel.grid.major.y = element_blank(),
              legend.justification="left",
              legend.position = "bottom",
              legend.direction="horizontal",
              legend.background = element_blank(),
              legend.title = element_blank(),
              legend.key = element_rect(fill = "white"),
              plot.title = element_text(face="bold",family = "serif",size=15),
              axis.text.y = element_text(hjust = 0,vjust=1))+
  guides(colour = guide_legend(override.aes=list(fill=c("#608098","white"))))

#In order to expand the background over axis y I had to use the trick below I was able to find this
#information in
#https://stackoverflow.com/questions/46626326/ggplot2-y-axis-labels-left-justified-inside-plot-area
#The main idea is focus on updating the ggplot to a ggplotGrob and changing the label grob related
#to y axis

gp <- ggplotGrob(g)
y.label.grob <- gp$grobs[[which(gp$layout$name == "axis-l")]]$children$axis    
gp$grobs[[which(gp$layout$name == "axis-l")]] <- zeroGrob()
gp$widths[gp$layout$l[which(gp$layout$name == "axis-l")]] <- unit(0, "cm")
new.y.label.grob <- gtable(heights = unit(1, "npc"))
new.y.label.grob <- gtable_add_cols(new.y.label.grob,widths = y.label.grob[["widths"]][2])
new.y.label.grob <- gtable_add_grob(new.y.label.grob,y.label.grob[["grobs"]][[2]],t = 1, l = 1)
new.y.label.grob <- gtable_add_cols(new.y.label.grob,widths = y.label.grob[["widths"]][1])
new.y.label.grob <- gtable_add_grob(new.y.label.grob,y.label.grob[["grobs"]][[1]],t = 1, l = 2)
new.y.label.grob <- gtable_add_cols(new.y.label.grob,widths = unit(1, "null"))
gp <- gtable_add_grob(gp,new.y.label.grob,t = gp$layout$t[which(gp$layout$name == "panel")],
                      l = gp$layout$l[which(gp$layout$name == "panel")])
grid.draw(gp)